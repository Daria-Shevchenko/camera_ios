//
//  Camera_appApp.swift
//  Camera_app
//
//  Created by Daria Shevchenko on 03.12.2022.
//

import SwiftUI

@main
struct Camera_appApp: App {
    var body: some Scene {
        WindowGroup {
            Main()
        }
    }
}
